export const SEASON = Object.freeze({
  id: 'street-shop',
  number: '01',
  title: '街角旧店',
  description: '九处小小的日常，等你慢慢收好。',
  story: '灯亮起来，唱片转起来。让街角这家小店，再一次开门。',
  openingId: 'opening',
  chapters: [
    {
      number: '一',
      title: '收拾日常',
      description: '从身边的小事开始。',
      levelIds: ['coffee', 'desk', 'tea'],
    },
    {
      number: '二',
      title: '让旧物复苏',
      description: '留一点耐心，让它重新好用。',
      levelIds: ['record', 'plant', 'clock'],
    },
    {
      number: '三',
      title: '重新开门',
      description: '把光和日常，重新请进店里。',
      levelIds: ['window', 'sign', 'opening'],
    },
  ],
  restorationIds: ['coffee', 'desk', 'tea', 'record', 'plant', 'clock', 'window', 'sign'],
});
export const seasonLevelIds = (season) => season.chapters.flatMap((chapter) => chapter.levelIds);
