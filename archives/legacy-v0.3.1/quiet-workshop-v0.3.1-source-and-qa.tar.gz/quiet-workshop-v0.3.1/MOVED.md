# 项目已独立

好好收拾的后续开发由独立项目 `/Users/hongboy/projects/quiet-workshop` 管理。
本目录保留第一季 0.3.1 的历史源码与 QA，不再作为开发入口。
新的 AGENTS.md、两季源码、发布配置及当前运行记录位于独立项目。
